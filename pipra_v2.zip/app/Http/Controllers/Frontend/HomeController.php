<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Project;

class HomeController extends Controller
{
  public function index()
  {
    $projects = Project::orderBy('serial', 'desc')->get();
    return view('frontend.home.index', compact('projects'));
  }

  public function projects()
  {
    $projects = Project::orderBy('serial', 'desc')->get();
    return view('frontend.home.projects', compact('projects'));
  }

  public function about()
  {
    return view('frontend.about.index');
  }

  public function services()
  {
    return view('frontend.services.index');
  }

  public function contact()
  {
    return view('frontend.contact.index');
  }

  public function projectDetails(Project $project)
  {
    return view('frontend.home.project', compact('project'));
  }
}
