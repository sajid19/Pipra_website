@extends('administrative.layouts.master')
@section('page-css')
<link rel="stylesheet" href="{{ asset('assets/css/dashboard-css/dashboard-css.css') }}">
@endsection
@section('content')
<div class="dash container">
    <div class="user-intro">
        <h2>Welcome Back!</h1>
            <h4>{{ auth()->user()->name }}</h3>
    </div>
</div>
@endsection
@section('page-js')

@endsection