<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
    <p class="text-muted text-center text-md-left">Copyright © {{date('Y')}} Pipra</p>
    <p class="text-muted text-center text-md-right">version 1.0</p>

</footer>