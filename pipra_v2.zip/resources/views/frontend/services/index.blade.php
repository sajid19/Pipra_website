@extends('frontend.layouts.master')
@section('content')
@php
$img1 = 'frontend/img/background/ptn-1.png';
$img2 = 'frontend/img/background/bg-11.jpg';
@endphp
@php
$img2 = 'frontend/img/carousel-1.jpg';
@endphp
<!-- INNER PAGE BANNER -->
<div class="wt-bnr-inr overlay-wraper bg-parallax bg-top-center py-5 mb-5 wow fadeIn" data-stellar-background-ratio="0.5" style="background-image:url('{{asset($img2)}}')" data-wow-delay="0.1s">
  <div class="overlay-main bg-black opacity-07"></div>
  <div class="container">
    <div class="wt-bnr-inr-entry">
      <div class="banner-title-outer">
        <div class="banner-title-name">
          <h2 class="text-white text-uppercase letter-spacing-5 font-18 font-weight-300">Services</h2>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page Header End -->
<!-- Facts Start -->
<div class="container-xxl py-5">
  <div class="container pt-5">
    <div class="row g-4">
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
        <div class="fact-item text-center bg-light h-100 p-5 pt-0">
          <div class="fact-icon">
            <img src="{{ asset('frontend/img/icons/icon-2.png') }}" alt="Icon">
          </div>
          <h3 class="mb-3">Design Approach</h3>
          <p class="mb-0">We blend creativity and functionality to craft spaces that inspire and endure,
            Our designs prioritize sustainability and innovation.</p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
        <div class="fact-item text-center bg-light h-100 p-5 pt-0">
          <div class="fact-icon">
            <img src="{{ asset('frontend/img/icons/icon-3.png') }}" alt="Icon">
          </div>
          <h3 class="mb-3">Innovative Solutions</h3>
          <p class="mb-0">We leverage cutting-edge technology and forward-thinking designs to transform
            visions into reality.</p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
        <div class="fact-item text-center bg-light h-100 p-5 pt-0">
          <div class="fact-icon">
            <img src="{{ asset('frontend/img/icons/icon-4.pn') }}g" alt="Icon">
          </div>
          <h3 class="mb-3">Project Management</h3>
          <p class="mb-0">Our meticulous project management ensures timely delivery and exceptional
            quality at every stage.</p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Facts End -->

<!-- Service Start -->
<div class="container-xxl py-5">
  <div class="container">
    <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
      <h4 class="section-title">Our Services</h4>
      <h1 class="display-5 mb-4">We Focused On Modern Architecture And Interior Design</h1>
    </div>
    <div class="row g-4">
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
        <div class="service-item d-flex position-relative text-center h-100">
          <img class="bg-img" src="{{ asset('frontend/img/service-1.jpg') }}" alt="">
          <div class="service-text p-5">
            <img class="mb-4" src="{{ asset('frontend/img/icons/icon-5.png') }}" alt="Icon">
            <h3 class="mb-3">Architecture</h3>
            <p class="mb-4">Designing innovative and sustainable spaces that bring your vision to life
            </p>
            <a class="btn" href="#"><i class="fa fa-plus text-primary me-3"></i>Read More</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
        <div class="service-item d-flex position-relative text-center h-100">
          <img class="bg-img" src="{{ asset('frontend/img/service-2.jpg') }}" alt="">
          <div class="service-text p-5">
            <img class="mb-4" src="{{ asset('frontend/img/icons/icon-6.png') }}" alt="Icon">
            <h3 class="mb-3">3D Animation</h3>
            <p class="mb-4">Bringing designs to life with realistic and immersive 3D visualizations</p>
            <a class="btn" href="#"><i class="fa fa-plus text-primary me-3"></i>Read More</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
        <div class="service-item d-flex position-relative text-center h-100">
          <img class="bg-img" src="{{ asset('frontend/img/service-3.jpg') }}" alt="">
          <div class="service-text p-5">
            <img class="mb-4" src="{{ asset('frontend/img/icons/icon-7.png') }}" alt="Icon">
            <h3 class="mb-3">House Planning</h3>
            <p class="mb-4">Crafting detailed and functional plans to create your perfect home</p>
            <a class="btn" href="#"><i class="fa fa-plus text-primary me-3"></i>Read More</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
        <div class="service-item d-flex position-relative text-center h-100">
          <img class="bg-img" src="{{ asset('frontend/img/service-4.jpg') }}" alt="">
          <div class="service-text p-5">
            <img class="mb-4" src="{{ asset('frontend/img/icons/icon-8.png') }}" alt="Icon">
            <h3 class="mb-3">Interior Design</h3>
            <p class="mb-4">Transforming spaces with aesthetic and functional interior solutions
              tailored to your style</p>
            <a class="btn" href="#"><i class="fa fa-plus text-primary me-3"></i>Read More</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
        <div class="service-item d-flex position-relative text-center h-100">
          <img class="bg-img" src="{{ asset('frontend/img/service-5.jpg') }}" alt="">
          <div class="service-text p-5">
            <img class="mb-4" src="{{ asset('frontend/img/icons/icon-9.png') }}" alt="Icon">
            <h3 class="mb-3">Renovation</h3>
            <p class="mb-4">Revitalizing existing spaces with modern designs and enhanced functionality
            </p>
            <a class="btn" href="#"><i class="fa fa-plus text-primary me-3"></i>Read More</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
        <div class="service-item d-flex position-relative text-center h-100">
          <img class="bg-img" src="{{ asset('frontend/img/service-6.jpg') }}" alt="">
          <div class="service-text p-5">
            <img class="mb-4" src="{{ asset('frontend/img/icons/icon-10.png') }}" alt="Icon">
            <h3 class="mb-3">Construction</h3>
            <p class="mb-4">Building high-quality, durable structures with precision and expertise</p>
            <a class="btn" href="#"><i class="fa fa-plus text-primary me-3"></i>Read More</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Service End -->

<!-- TESTIMONIALS SECTION START -->
<div class="section-full p-t80 clearfixbg-repeat " style="background-image:url('{{asset($img1)}}');">
  <div class="container">
    <div class="section-content">
      <!-- TITLE START -->
      <div class="section-head text-left">
        <h2 class="text-uppercase font-36">Testimonials</h2>
        <div class="wt-separator-outer">
          <div class="wt-separator bg-black"></div>
        </div>
      </div>
      <!-- TITLE END -->
      <!-- TESTIMONIAL 4 START ON BACKGROUND -->
      <div class="section-content">
        <div class="owl-carousel testimonial-home">
          <div class="item wow fadeInRight" data-wow-delay="0.1s">
            <div class="testimonial-6">
              <div class="testimonial-pic-block">
                <div class="testimonial-pic">
                  <img src="{{ asset('frontend/img/testimonials/pic1.jpg') }}" width="132" height="132" alt="">
                </div>
              </div>
              <div class="testimonial-text clearfix bg-white">
                <div class="testimonial-detail clearfix">
                  <strong class="testimonial-name">Taylor Roberts</strong>
                  <span class="testimonial-position p-t0">Co-manager associated</span>
                </div>
                <div class="testimonial-paragraph text-black p-t15">
                  <span class="fa fa-quote-left"></span>
                  <p>typefaces and layouts, and in appearance of different general the
                    content of dummy text is nonsensical.typefaces of dummy text is
                    nonsensical.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="item wow fadeInRight" data-wow-delay="0.2s">
            <div class="testimonial-6">
              <div class="testimonial-pic-block">
                <div class="testimonial-pic">
                  <img src="{{ asset('frontend/img/testimonials/pic4.jpg') }}" width="132" height="132" alt="">
                </div>
              </div>
              <div class="testimonial-text clearfix bg-white">
                <div class="testimonial-detail clearfix">
                  <strong class="testimonial-name">Robert willson</strong>
                  <span class="testimonial-position p-t0">Co-manager associated</span>
                </div>
                <div class="testimonial-paragraph text-black p-t15">
                  <span class="fa fa-quote-left"></span>
                  <p>typefaces and layouts, and in appearance of different general the
                    content of dummy text is nonsensical.typefaces of dummy text is
                    nonsensical.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="item wow fadeInRight" data-wow-delay="0.3s">
            <div class="testimonial-6">
              <div class="testimonial-pic-block">
                <div class="testimonial-pic">
                  <img src="{{ asset('frontend/img/testimonials/pic2.jpg') }}" width="132" height="132" alt="">
                </div>
              </div>
              <div class="testimonial-text clearfix bg-white">
                <div class="testimonial-detail clearfix">
                  <strong class="testimonial-name">Taylor Roberts</strong>
                  <span class="testimonial-position p-t0">Co-manager associated</span>
                </div>
                <div class="testimonial-paragraph text-black p-t15">
                  <span class="fa fa-quote-left"></span>
                  <p>typefaces and layouts, and in appearance of different general the
                    content of dummy text is nonsensical.typefaces of dummy text is
                    nonsensical.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="testimonial-6">
              <div class="testimonial-pic-block">
                <div class="testimonial-pic">
                  <img src="{{ asset('frontend/img/testimonials/pic3.jpg') }}" width="132" height="132" alt="">
                </div>
              </div>
              <div class="testimonial-text clearfix bg-white">
                <div class="testimonial-detail clearfix">
                  <strong class="testimonial-name">Robert willson</strong>
                  <span class="testimonial-position p-t0">Co-manager associated</span>
                </div>
                <div class="testimonial-paragraph text-black p-t15">
                  <span class="fa fa-quote-left"></span>
                  <p>typefaces and layouts, and in appearance of different general the
                    content of dummy text is nonsensical.typefaces of dummy text is
                    nonsensical.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="testimonial-6">
              <div class="testimonial-pic-block">
                <div class="testimonial-pic">
                  <img src="{{ asset('frontend/img/testimonials/pic1.jpg') }}" width="132" height="132" alt="">
                </div>
              </div>
              <div class="testimonial-text clearfix bg-white">
                <div class="testimonial-detail clearfix">
                  <strong class="testimonial-name">Taylor Roberts</strong>
                  <span class="testimonial-position p-t0">Co-manager associated</span>
                </div>
                <div class="testimonial-paragraph text-black p-t15">
                  <span class="fa fa-quote-left"></span>
                  <p>typefaces and layouts, and in appearance of different general the
                    content of dummy text is nonsensical.typefaces of dummy text is
                    nonsensical.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="testimonial-6">
              <div class="testimonial-pic-block">
                <div class="testimonial-pic">
                  <img src="{{ asset('frontend/img/testimonials/pic4.jpg') }}" width="132" height="132" alt="">
                </div>
              </div>
              <div class="testimonial-text clearfix bg-white">
                <div class="testimonial-detail clearfix">
                  <strong class="testimonial-name">Taylor Roberts</strong>
                  <span class="testimonial-position p-t0">Co-manager associated</span>
                </div>
                <div class="testimonial-paragraph text-black p-t15">
                  <span class="fa fa-quote-left"></span>
                  <p>typefaces and layouts, and in appearance of different general the
                    content of dummy text is nonsensical.typefaces of dummy text is
                    nonsensical.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="hilite-title p-lr20 m-tb20 text-right text-uppercase bdr-gray bdr-right">
      <strong>Client</strong>
      <span class="text-black">Says</span>
    </div>
  </div>
</div>
<!-- TESTIMONIALS SECTION END -->
@endsection