@extends('frontend.layouts.master')
@section('content')
<!-- Page Header Start -->
@php
$img2 = 'frontend/img/carousel-1.jpg';
@endphp
<!-- INNER PAGE BANNER -->
<div class="wt-bnr-inr overlay-wraper bg-parallax bg-top-center py-5 mb-5 wow fadeIn" data-stellar-background-ratio="0.5" style="background-image:url('{{asset($img2)}}')" data-wow-delay="0.1s">
  <div class="overlay-main bg-black opacity-07"></div>
  <div class="container">
    <div class="wt-bnr-inr-entry">
      <div class="banner-title-outer">
        <div class="banner-title-name">
          <h2 class="text-white text-uppercase letter-spacing-5 font-18 font-weight-300">About us</h2>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page Header End -->
<!-- About Start -->
<div class="container-xxl py-5">
  <div class="container">
    <div class="row g-5">
      <div class="col-lg-6 wow slideInLeft" data-wow-delay="0.1s">
        <div class="about-img">
          <img class="img-fluid" src="{{ asset('frontend/img/about-1.jpg') }}" alt="">
          <img class="img-fluid" src="{{ asset('frontend/img/about-2.jpg') }}" alt="">
        </div>
      </div>
      <div class="col-lg-6 wow slideInRight" data-wow-delay="0.1s">
        <h4 class="section-title">About Us</h4>
        <h1 class="display-5 mb-4">A Creative Architecture Agency For Your Dream Home</h1>
        <p>At our creative architecture agency, we specialize in turning your dream home into a stunning
          reality. Our team combines innovative design with meticulous attention to detail, ensuring that
          every aspect of your home reflects your unique vision and lifestyle</p>
        <p>
          With a focus on sustainability and functionality, we create living spaces that are not only
          beautiful but also enduring and efficient. Let us bring your dream home to life with our expert
          architectural solutions.
        </p>
        <div class="d-flex align-items-center mb-5">
          <div class="d-flex flex-shrink-0 align-items-center justify-content-center border border-5 border-primary" style="width: 120px; height: 120px;">
            <h1 class="display-1 mb-n2" data-toggle="counter-up">3</h1>
          </div>
          <div class="ps-4">
            <h3>Years</h3>
            <h3>Working</h3>
            <h3 class="mb-0">Experience</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- About End -->

<!-- Feature Start -->
<div class="container-xxl py-5">
  <div class="container">
    <div class="row g-5">
      <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
        <h4 class="section-title">Why Choose Us!</h4>
        <h1 class="display-5 mb-4">Why You Should Trust Us? Learn More About Us!</h1>
        <div class="row g-4">
          <div class="col-12">
            <div class="d-flex align-items-start">
              <img class="flex-shrink-0" src="{{ asset('frontend/img/icons/icon-2.png') }}" alt="Icon">
              <div class="ms-4">
                <h3>Design Approach</h3>
                <p class="mb-0">We blend creativity and functionality to craft spaces that inspire
                  and endure, Our designs prioritize sustainability and innovation.</p>
              </div>
            </div>
          </div>
          <div class="col-12">
            <div class="d-flex align-items-start">
              <img class="flex-shrink-0" src="{{ asset('frontend/img/icons/icon-3.png') }}" alt="Icon">
              <div class="ms-4">
                <h3>Innovative Solutions</h3>
                <p class="mb-0">We leverage cutting-edge technology and forward-thinking designs to
                  transform visions into reality.</p>
              </div>
            </div>
          </div>
          <div class="col-12">
            <div class="d-flex align-items-start">
              <img class="flex-shrink-0" src="{{ asset('frontend/img/icons/icon-4.png') }}" alt="Icon">
              <div class="ms-4">
                <h3>Project Management</h3>
                <p class="mb-0">Our meticulous project management ensures timely delivery and
                  exceptional quality at every stage.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
        <div class="feature-img">
          <img class="img-fluid" src="{{ asset('frontend/img/about-2.jpg') }}" alt="">
          <img class="img-fluid" src="{{ asset('frontend/img/about-1.jpg') }}" alt="">
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Feature End -->

<!-- Team Start -->
<div class="container-xxl py-5">
  <div class="container">
    <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
      <h4 class="section-title">Team Members</h4>
      <h1 class="display-5 mb-4">We Are Creative Architecture Team For Your Dream Home</h1>
    </div>
    <div class="row g-0 team-items">
      <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
        <div class="team-item position-relative">
          <div class="position-relative">
            <img class="img-fluid" src="{{ asset('frontend/img/team-1.jpg') }}" alt="">
            <div class="team-social text-center">
              <a class="btn btn-square" href="#"><i class="fab fa-facebook-f"></i></a>
              <a class="btn btn-square" href="#"><i class="fab fa-twitter"></i></a>
              <a class="btn btn-square" href="#"><i class="fab fa-instagram"></i></a>
            </div>
          </div>
          <div class="bg-light text-center p-4">
            <h3 class="mt-2">Architect Name</h3>
            <span class="text-primary">Designation</span>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
        <div class="team-item position-relative">
          <div class="position-relative">
            <img class="img-fluid" src="{{ asset('frontend/img/team-2.jpg') }}" alt="">
            <div class="team-social text-center">
              <a class="btn btn-square" href="#"><i class="fab fa-facebook-f"></i></a>
              <a class="btn btn-square" href="#"><i class="fab fa-twitter"></i></a>
              <a class="btn btn-square" href="#"><i class="fab fa-instagram"></i></a>
            </div>
          </div>
          <div class="bg-light text-center p-4">
            <h3 class="mt-2">Architect Name</h3>
            <span class="text-primary">Designation</span>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
        <div class="team-item position-relative">
          <div class="position-relative">
            <img class="img-fluid" src="{{ asset('frontend/img/team-3.jpg') }}" alt="">
            <div class="team-social text-center">
              <a class="btn btn-square" href="#"><i class="fab fa-facebook-f"></i></a>
              <a class="btn btn-square" href="#"><i class="fab fa-twitter"></i></a>
              <a class="btn btn-square" href="#"><i class="fab fa-instagram"></i></a>
            </div>
          </div>
          <div class="bg-light text-center p-4">
            <h3 class="mt-2">Architect Name</h3>
            <span class="text-primary">Designation</span>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
        <div class="team-item position-relative">
          <div class="position-relative">
            <img class="img-fluid" src="{{ asset('frontend/img/team-4.jpg') }}" alt="">
            <div class="team-social text-center">
              <a class="btn btn-square" href="#"><i class="fab fa-facebook-f"></i></a>
              <a class="btn btn-square" href="#"><i class="fab fa-twitter"></i></a>
              <a class="btn btn-square" href="#"><i class="fab fa-instagram"></i></a>
            </div>
          </div>
          <div class="bg-light text-center p-4">
            <h3 class="mt-2">Architect Name</h3>
            <span class="text-primary">Designation</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Team End -->
@endsection