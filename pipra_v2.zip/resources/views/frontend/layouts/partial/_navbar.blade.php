<!-- Spinner Start -->
<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
    <div class="spinner-border position-relative text-primary" style="width: 6rem; height: 6rem;" role="status">
    </div>
    <img height="50" width="80" class="position-absolute top-50 start-50 translate-middle" src="{{asset('frontend/img/icons/icon-1.png')}}" alt="Icon">
</div>
<!-- Spinner End -->

<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
    <a href="{{route('home')}}" class="navbar-brand ms-4 ms-lg-0">
        <h1 class="text-primary m-0"><img height="70" width="100" class="me-3" src="{{asset('frontend/img/icons/icon-1.png')}}" alt="Icon">
        </h1>
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="{{route('home')}}" class="nav-item nav-link {{ request()->is('/') ? 'active' : '' }}">Home</a>
            <a href=" {{route('about')}}" class="nav-item nav-link {{ request()->is('about') ? 'active' : '' }}">About</a>
            <a href="{{route('services')}}" class="nav-item nav-link {{ request()->is('services') ? 'active' : '' }}">Services</a>
            <a href="{{route('projects')}}" class="nav-item nav-link {{ request()->is('projects') ? 'active' : '' }}">Projects</a>
            <!-- <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Projects</a>
                <div class="dropdown-menu border-0 m-0">
                    <a href="{{route('home')}}" class="dropdown-item">Project 1</a>
                </div>
            </div> -->
            <a href="{{route('contact')}}" class="nav-item nav-link {{ request()->is('contact') ? 'active' : '' }}">Contact</a>
        </div>
    </div>
</nav>
<!-- Navbar End -->