<?php $__env->startSection('page-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
    <div>
        <h4 class="mb-3 mb-md-0">Project Create</h4>
    </div>
    <div class="d-flex align-items-center flex-wrap text-nowrap">
        <a href="<?php echo e(route('administrative.project')); ?>" class="btn btn-primary btn-icon-text mb-2 mb-md-0">
            <i class="btn-icon-prepend" data-feather="server"></i>
            Project List
        </a>
    </div>
</div>
<div class="row">
    <div class="col-md-8 grid-margin stretch-card offset-md-2">
        <div class="card">
            <div class="card-body">
                <h6 class="card-title">Project Create</h6>
                <form class="forms-sample" action="<?php echo e(route('administrative.project.store')); ?> " method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                    <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

                    <?php endif; ?>
                    <div class="form-group <?php echo e($errors->has('title') ? 'has-danger' : ''); ?>">
                        <label for="title">Title</label>
                        <input required type="text" class="form-control form-control-danger" id="title" name="title" autocomplete="off" placeholder="Title" aria-invalid="true">
                        <?php if($errors->has('title')): ?>
                        <label id="title-error" class="error mt-2 text-danger" for="title">Please enter a project title</label>
                        <?php endif; ?>
                    </div>

                    <div class="form-group <?php echo e($errors->has('sub_title') ? 'has-danger' : ''); ?>">
                        <label for="sub_title">Sub Title</label>
                        <textarea type="text" class="form-control form-height <?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sub_title" rows="4" name="sub_title"></textarea>
                        <?php if($errors->has('sub_title')): ?>
                        <label id="sub_title-error" class="error mt-2 text-danger" for="title">Please enter a project sub title</label>
                        <?php endif; ?>
                    </div>

                    <div class="form-group <?php echo e($errors->has('description') ? 'has-danger' : ''); ?>">
                        <label for="description">Description</label>
                        <textarea type="text" class="form-control form-height <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" rows="8" name="description"></textarea>
                        <?php if($errors->has('description')): ?>
                        <label id="description-error" class="error mt-2 text-danger" for="title">Please enter a description</label>
                        <?php endif; ?>
                    </div>

                    <div class="form-group <?php echo e($errors->has('name') ? 'has-danger' : ''); ?>">
                        <label for="name">Select Image (Width 360px, Height 560px)</label>
                        <input required style="height: 35px;" type="file" id="file" name="file" class="file-upload-default">
                        <div style="height: 35px;" class="input-group col-xs-12">
                            <input type="text" class="form-control file-upload-info" disabled="" placeholder="Image">
                            <span class="input-group-append">
                                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                            </span>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    <a href="<?php echo e(route('administrative.project')); ?>" class="btn btn-light">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
    $(function() {
        CKEDITOR.replace('sub_title', {
            filebrowserImageBrowseUrl: '/file-manager/ckeditor'
        });
    });
    $(function() {
        CKEDITOR.replace('description', {
            filebrowserImageBrowseUrl: '/file-manager/ckeditor'
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrative.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridwan/Ridwan/Ridwan/pipra/resources/views/administrative/project/create.blade.php ENDPATH**/ ?>