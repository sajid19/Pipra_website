<?php $__env->startSection('content'); ?>
<!-- Page Header Start -->
<?php
$img2 = 'frontend/img/carousel-1.jpg';
?>
<!-- INNER PAGE BANNER -->
<div class="wt-bnr-inr overlay-wraper bg-parallax bg-top-center py-5 mb-5 wow fadeIn" data-stellar-background-ratio="0.5" style="background-image:url('<?php echo e(asset($img2)); ?>')" data-wow-delay="0.1s">
  <div class="overlay-main bg-black opacity-07"></div>
  <div class="container">
    <div class="wt-bnr-inr-entry">
      <div class="banner-title-outer">
        <div class="banner-title-name">
          <h2 class="text-white text-uppercase letter-spacing-5 font-18 font-weight-300">Contact</h2>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Page Header End -->
<!-- Google Map Start -->
<div class="container-xxl pt-5 px-0 wow fadeIn" data-wow-delay="0.1s">
  <iframe class="w-100 mb-n2" style="height: 450px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3620.446133577837!2d89.36543697530392!3d24.848607977936975!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fc5527d3b9693d%3A0x32693e6ff983ee93!2sShop%20No%3A%2081%2C82%2C%20Railway%20Market%2C%20Station%20Road%2C%20Bogura!5e0!3m2!1sen!2sbd!4v1716643250556!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
<!-- Google Map End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridwan/Ridwan/Ridwan/pipra/resources/views/frontend/contact/index.blade.php ENDPATH**/ ?>