<!doctype html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="version" content="version=1.01">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Pipra - Construction Company</title>


    <meta name="description" content="ONE STOP BUILDING SOLUTIONS, Consultancy - Construction - Building Materials">
    <meta name="keywords" content="default, keywords">
    <meta name="robots" content="index, follow">

    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="পিঁপড়া - Construction Company">
    <meta property="og:description" content="ONE STOP BUILDING SOLUTIONS, Consultancy - Construction - Building Materials">
    <meta property="og:image" content="<?php echo e(asset('frontend/img/icons/icon-1.png')); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:type" content="website">

    <!-- Canonical Link -->
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">


    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('frontend/img/favicon.html')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/main.css')); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600&amp;family=Teko:wght@400;500;600&amp;display=swap" rel="stylesheet">

    <link href="<?php echo e(asset('frontend/cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/cdn.jsdelivr.net/npm/bootstrap-icons%401.4.1/font/bootstrap-icons.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('frontend/lib/animate/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>">
    <link href="<?php echo e(asset('frontend/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/magnific-popup.min.css')); ?>">
    <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('frontend/css/style2.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/plugins/revolution/revolution/css/settings.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/plugins/revolution/revolution/css/navigation.css')); ?>">
    <?php echo $__env->yieldContent('page-css'); ?>
</head>

<body>

    
    <?php echo $__env->make('frontend.layouts.partial._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    
    <?php echo $__env->make('frontend.layouts.partial._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>

    <script src="<?php echo e(asset('assets/vendor_assets/js/jquery/jquery-3.5.1.min.js')); ?>"></script>

    <script src="<?php echo e(asset('frontend/code.jquery.com/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/counterup/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/tempusdominus/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/tempusdominus/js/moment-timezone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/scrolla.min.js')); ?>"></script><!-- ON SCROLL CONTENT ANIMTE   -->
    <script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script><!-- CUSTOM FUCTIONS  -->
    <script src="<?php echo e(asset('frontend/js/shortcode.js')); ?>"></script>

    <!-- REVOLUTION JS FILES -->
    <script src="<?php echo e(asset('frontend/plugins/revolution/revolution/js/jquery.themepunch.tools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/plugins/revolution/revolution/js/extensions/revolution-plugin.js')); ?>"></script>

    <!-- REVOLUTION SLIDER SCRIPT FILES -->
    <script src="<?php echo e(asset('frontend/js/rev-script-1.js')); ?>"></script>

    <?php echo $__env->yieldContent('page-js'); ?>
</body>

</html><?php /**PATH /home/ridwan/Ridwan/Ridwan/pipra/resources/views/frontend/layouts/master.blade.php ENDPATH**/ ?>