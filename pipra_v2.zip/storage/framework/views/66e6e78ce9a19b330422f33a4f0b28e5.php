<?php $__env->startSection('page-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dashboard-css/dashboard-css.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="dash container">
    <div class="user-intro">
        <h2>Welcome Back!</h1>
            <h4><?php echo e(auth()->user()->name); ?></h3>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrative.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridwan/Ridwan/Ridwan/pipra/resources/views/administrative/dashboard.blade.php ENDPATH**/ ?>