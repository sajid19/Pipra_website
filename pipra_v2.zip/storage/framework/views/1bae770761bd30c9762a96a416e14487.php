<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
    <p class="text-muted text-center text-md-left">Copyright © <?php echo e(date('Y')); ?> Pipra</p>
    <p class="text-muted text-center text-md-right">version 1.0</p>

</footer><?php /**PATH /home/ridwan/Ridwan/Ridwan/pipra/resources/views/administrative/layouts/partial/_footer.blade.php ENDPATH**/ ?>