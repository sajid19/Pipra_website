<nav class="sidebar">
    <div class="sidebar-header">
        <a href="<?php echo e(route('administrative.dashboard')); ?>" class="sidebar-brand">
            <img src="<?php echo e(asset('assets/images/pipra.png')); ?>" height="100px" width="140px">
        </a>
        <div class="sidebar-toggler not-active">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <div class="sidebar-body">
        <ul class="nav">
            <li class="nav-item nav-category">Main</li>
            <li class="nav-item <?php echo e(request()->is('administrative/dashboard') ? 'active' : ''); ?> ">
                <a href="<?php echo e(route('administrative.dashboard')); ?>" class="nav-link parent-link">
                    <i class="link-icon" data-feather="align-left"></i>
                    <span class="link-title">Dashboard</span>
                </a>
            </li>

            <li class="nav-item nav-category">Components</li>
            <li class="nav-item <?php echo e(request()->is('administrative/project/*') ? 'active' : ''); ?> ">
                <a href="<?php echo e(route('administrative.project')); ?>" class="nav-link parent-link">
                    <i class="link-icon" data-feather="align-left"></i>
                    <span class="link-title">Project</span>
                </a>
            </li>

        </ul>
    </div>
</nav><?php /**PATH /home/ridwan/Ridwan/Ridwan/pipra/resources/views/administrative/layouts/partial/_sidebar.blade.php ENDPATH**/ ?>