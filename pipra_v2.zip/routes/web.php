<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Administrative\AuthController;
use App\Http\Controllers\Administrative\ProjectController;
use App\Http\Controllers\Frontend\HomeController as FrontendHomeController;
use App\Http\Controllers\Administrative\HomeController as AdministrativeHomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [FrontendHomeController::class, 'index'])->name('home');

Route::get('/about', [FrontendHomeController::class, 'about'])->name('about');

Route::get('/projects', [FrontendHomeController::class, 'projects'])->name('projects');

Route::get('/project/{project}', [FrontendHomeController::class, 'projectDetails'])->name('project.details');

Route::get('/services', [FrontendHomeController::class, 'services'])->name('services');

Route::get('/contact', [FrontendHomeController::class, 'contact'])->name('contact');

Route::get('/login', [AuthController::class, 'index'])->name('login');

Route::post('login', [AuthController::class, 'authenticate'])->name('login.post');

Route::namespace('Administrative')->middleware('auth')->prefix('administrative')->name('administrative.')->group(function () {

    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('/dashboard', [AdministrativeHomeController::class, 'index'])->name('dashboard');

    // Project
    Route::prefix('project')->group(function () {
        Route::get('/list', [ProjectController::class, 'index'])->name('project');

        Route::get('project-data', [ProjectController::class, 'data'])->name('project.data');

        Route::get('edit/{project}', [ProjectController::class, 'edit'])->name('project.edit');

        Route::delete('delete/{project}', [ProjectController::class, 'destroy'])->name('project.destroy');

        Route::get('create', [ProjectController::class, 'create'])->name('project.create');

        Route::post('create', [ProjectController::class, 'store'])->name('project.store');

        Route::put('update/{project}', [ProjectController::class, 'update'])->name('project.update');
    });
});
